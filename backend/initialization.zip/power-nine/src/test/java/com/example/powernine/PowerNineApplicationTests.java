package com.example.powernine;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PowerNineApplicationTests {

	@Test
	void contextLoads() {
	}

}
